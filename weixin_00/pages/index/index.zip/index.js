//index.js
//获取应用实例
const app = getApp()
Page({
  handleTap2:function(event){
     console.log("父元素");
     console.log("1:"+event.type);
     console.log("2:"+event.timeStamp);
     console.log(event.currentTarget);//当前元素
     console.log(event.target);//子元素
  },
  handleTap1:function(event){
    console.log(123);
    //console.log("1:"+event.type);
    //console.log("2:"+event.timeStamp);
    // console.log(event.currentTarget);
    //console.log(event.target);
  },
  handleTap3:function(){
    console.log("3:longtap");
  },
  handleTap4:function(e){
    console.log("4:longpress");
    //console.log(e.dataset.idx);
    console.log(e.target.dataset.idx);
  },
  /**
   * 页面的初始数据
   */
  data: {
    
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})